﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hafta6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            KrediKart basla=new KrediKart();
            basla.Baslat();

        }
    }
    public class KrediKart
    {
        public int kartbakiyesi;
        public int ekbakiye;
        public int yapıalacakHarcama;
        public int anabakiye ;
        public int TotalHarcama;
        public int AdSoyad;


        public void Baslat()
        {
            YemekKart yemek = new YemekKart();
            UlaşımKart ulasım = new UlaşımKart();
            EglenceKart eglence = new EglenceKart();
            GiyimKart giyim = new GiyimKart();
            KrediKart kredi = new KrediKart();
            Console.WriteLine("adınız soyadınız: ");
            string AdSoyad=Console.ReadLine();
           
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("hangi karttan alışveriş yapacaksınız ulaşım için :1 yemek için:2 Eglence için:3 ve Giyim için:4 ve diğer işlemeriniz için: 5 basınız?");
                int KartSecimi = Convert.ToInt32(Console.ReadLine());
                if (KartSecimi == 1)

                {
                    Console.WriteLine("Ulaşım kartını seçtiniz.");
                    int AnabakiyedenDüsülecekMiktar = yemek.TotalHarcama + ulasım.TotalHarcama + eglence.TotalHarcama + giyim.TotalHarcama + kredi.TotalHarcama;
                    ulasım.anabakiye =20000- AnabakiyedenDüsülecekMiktar;
                    this.anabakiye = ulasım.anabakiye;

                    ulasım.BakiyeHesaplamaMetodu();
                    ulasım.bilgiGoster();
                }
                if (KartSecimi == 2)
                {
                    Console.WriteLine("Yemek kartını seçtiniz.");
                    int AnabakiyedenDüsülecekMiktar = yemek.TotalHarcama + ulasım.TotalHarcama + eglence.TotalHarcama + giyim.TotalHarcama + kredi.TotalHarcama;
                    yemek.anabakiye = 20000 - AnabakiyedenDüsülecekMiktar;
                    this.anabakiye = yemek.anabakiye;
                    yemek.BakiyeHesaplamaMetodu();
                    yemek.bilgiGoster();

                }
                if (KartSecimi == 3)
                {
                    Console.WriteLine("Eğlence kartını seçtiniz.");
                    int AnabakiyedenDüsülecekMiktar = yemek.TotalHarcama + ulasım.TotalHarcama + eglence.TotalHarcama + giyim.TotalHarcama + kredi.TotalHarcama;
                    eglence.anabakiye = 20000 - AnabakiyedenDüsülecekMiktar;
                    this.anabakiye= eglence.anabakiye;
                    eglence.BakiyeHesaplamaMetodu();
                    eglence.bilgiGoster();
                }
                if (KartSecimi == 4)
                {
                    Console.WriteLine("Giyim kartını seçtiniz.");
                    int AnabakiyedenDüsülecekMiktar = yemek.TotalHarcama + ulasım.TotalHarcama + eglence.TotalHarcama + giyim.TotalHarcama + kredi.TotalHarcama;
                    giyim.anabakiye = 20000- AnabakiyedenDüsülecekMiktar;
                    this.anabakiye=giyim.anabakiye;
                    giyim.BakiyeHesaplamaMetodu();
                    giyim.bilgiGoster();

                }
                if (KartSecimi == 5)
                {
                    Console.WriteLine("Diğer ödemeler kartını seçtiniz.");
                    int AnabakiyedenDüsülecekMiktar = yemek.TotalHarcama + ulasım.TotalHarcama + eglence.TotalHarcama + giyim.TotalHarcama + kredi.TotalHarcama;
                    kredi.anabakiye = 20000- AnabakiyedenDüsülecekMiktar;
                    this.anabakiye = kredi.anabakiye;
                    kredi.DigerHarcamalarBakiyeHesaplamaMetodu();
                }

            }
        }
        public void BakiyeHesaplamaMetodu()
        {

            Console.WriteLine("Kaç tane harcama yapacaksınız 5 ve üssü harcama yapabilirsiniz.");
            int islemsayısı = Convert.ToInt32(Console.ReadLine());
            if (islemsayısı>=5)
            {
                Console.WriteLine("anakabiyeniz:" + this.anabakiye);
                this.kartbakiyesi = 0;
                this.ekbakiye = 0;
                for (int i = 0; i < islemsayısı; i++)
                {
                    Console.WriteLine("harcamam gir:");

                    this.yapıalacakHarcama = Convert.ToInt32(Console.ReadLine());
                    int AradaDegerHarcama = this.yapıalacakHarcama;
                    int AraDegerEkBakiye = this.ekbakiye;
                    int AraDegerKartBakiye = kartbakiyesi;
                    this.TotalHarcama += yapıalacakHarcama;
                    int k = AradaDegerHarcama + AraDegerEkBakiye + AraDegerEkBakiye;
                    if (k > anabakiye)
                    {
                        Console.WriteLine(" yetersiz bakiye...");
                    }
                    else
                    {
                        int Toplam = yapıalacakHarcama + kartbakiyesi + ekbakiye;
                        if (Toplam > 4300)
                        {
                            this.kartbakiyesi = kartbakiyesi;
                            this.ekbakiye = ekbakiye;
                            Console.WriteLine(kartbakiyesi);
                            Console.WriteLine("Limitinizi Aştınız İşlem Yapamazsınız");
                            Console.WriteLine("Kart Limitinizden harcanan değer: " + (this.kartbakiyesi));
                            Console.WriteLine("ek bakiyenizden harcanan deger : " + this.ekbakiye);
                        }
                        else if (Toplam > 3500 && Toplam <= 4300)
                        {
                            ekbakiye = Toplam - 3500;
                            this.kartbakiyesi = 3500;
                            this.anabakiye -= yapıalacakHarcama;
                            Console.WriteLine("ek limitten ve limitinizden  harcama yapıldı...");
                            Console.WriteLine("kart Limitinizden harcanan deger: " + this.kartbakiyesi);
                            Console.WriteLine("ek bakiyeden harcanan değer: " + (this.ekbakiye));
                        }
                        else
                        {
                            this.kartbakiyesi += yapıalacakHarcama;
                            this.ekbakiye = ekbakiye;
                            this.anabakiye -= yapıalacakHarcama;
                            Console.WriteLine("İşleminiz Yapılmıştır..");
                            Console.WriteLine("kart bakiyeden harcanan değer" + this.kartbakiyesi);
                            Console.WriteLine("ek Limitinden harcanan değer" + (this.ekbakiye));
                        }

                        Console.WriteLine("kalan ana  bakiye" + this.anabakiye);
                        this.kartbakiyesi = kartbakiyesi;
                        Console.WriteLine("total kart bakiyeden harcanan değer: " + this.kartbakiyesi);
                        Console.WriteLine();
                        this.ekbakiye = ekbakiye;
                        Console.WriteLine("total ek bakiyeden  harcanan değer: " + this.ekbakiye);
                    }
                }
                Console.WriteLine("total harcama: " + TotalHarcama);


            }
            else
            {
                Console.WriteLine("5'ten az değer girdiniz üzgünüz ama işlem yapamazsınız.");
            }
            
        }

        public void DigerHarcamalarBakiyeHesaplamaMetodu()
        {
            Console.WriteLine("Kaç tane harcama yapacaksınız");
            int islemsayısı = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("anakabiyeniz:" + this.anabakiye);
            this.kartbakiyesi = 0;
            this.ekbakiye = 0;
            for (int i = 0; i < islemsayısı; i++)
            {
                Console.WriteLine("harcamam gir:");

                this.yapıalacakHarcama = Convert.ToInt32(Console.ReadLine());
                int AradaDegerHarcama = this.yapıalacakHarcama;
                int AraDegerEkBakiye = this.ekbakiye;
                int AraDegerKartBakiye = kartbakiyesi;
                this.TotalHarcama += yapıalacakHarcama;
                int k = AradaDegerHarcama + AraDegerEkBakiye + AraDegerEkBakiye;
                if (k > anabakiye)
                {
                    Console.WriteLine(" yetersiz bakiye...");
                }
                else
                {
                    this.TotalHarcama += yapıalacakHarcama;
                    this.kartbakiyesi += yapıalacakHarcama;
                    this.anabakiye -= yapıalacakHarcama;
                    this.anabakiye=this.anabakiye;
                    Console.WriteLine("kalan ana bakiyeniz: "+this.anabakiye);
                }
            }
            Console.WriteLine("total harcama: " + TotalHarcama);

            Console.WriteLine("AŞAĞIDA HESAP HAREKETLERİNİZ GÖSTERİLECEKTİR");
            Console.WriteLine("Sayın " + AdSoyad + " kart ana limitiniz: 20000 TL'dir. Bu kart ana bakiyeden  harcama yapılmıştır."+
                                " bu kartınızın bir aylık ekstresi:   " + this.TotalHarcama + 
                                " ana kartınızda kalan toplam bakiyeniz: " + this.anabakiye + " ve kartınızla yaptığınz alışveriş sayınız 5 veya 5'en büyüktür");

        }

        public void bilgiGoster()
        {
            Console.WriteLine("AŞAĞIDA HESAP HAREKETLERİNİZ GÖSTERİLECEKTİR");
            Console.WriteLine("Sayın " + AdSoyad + " kart ana limitiniz: 20000 TL'dir. Alt sanal kartlarınızın limiti 3500 + 800 TL olarak tanımlanmıştır." +
                                " bu kartınızın bir aylık ekstresi gösterilecektir: " + this.TotalHarcama + " bu kartınızda kalan bakiyeniz: " +(4300- (this.kartbakiyesi + this.ekbakiye)) +
                                " ana kartınızda kalan toplam bakiyeniz: " + this.anabakiye + " ve kartınızla yaptığınz alışveriş sayınız 5 veya 5'en büyüktür");
        }
    }
    public class UlaşımKart : KrediKart
    {



    }
    public class EglenceKart : KrediKart
    {

    }
    public class YemekKart : KrediKart
    {

    }
    public class GiyimKart : KrediKart
    {

    }


}
